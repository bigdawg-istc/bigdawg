insert into mimic2v26.d_patients values(0,'Smith','John');
insert into mimic2v26.d_patients values(1,'Doe','Jane');

