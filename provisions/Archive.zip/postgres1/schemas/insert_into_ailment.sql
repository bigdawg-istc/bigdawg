insert into ailment values(1,'cold');
